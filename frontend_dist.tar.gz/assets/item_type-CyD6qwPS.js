var l=(t=>(t.String="string",t.Select="select",t.Bool="bool",t.Text="text",t.Number="number",t.Float="float",t.MultiPath="multipath",t))(l||{});export{l as T};
